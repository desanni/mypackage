import function

print function.func(1.0)
