import numpy

def func(x):
    return numpy.cos(x)
